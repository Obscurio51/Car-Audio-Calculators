import React, { useState, useEffect } from 'react';

const ORIGINAL_ASCII = `
  ::::::::::: :::    ::: ::::::::::          ::::::::  :::    :::   :::   :::   ::::    ::: ::::::::::: ::::    :::     ::: ::::::::::: ::::::::  ::::::::: 
     :+:     :+:    :+: :+:                :+:    :+: :+:    :+:  :+:+: :+:+:  :+:+:   :+:     :+:     :+:+:   :+:   :+: :+:   :+:    :+:    :+: :+:    :+: 
    +:+     +:+    +:+ +:+                +:+    +:+ +:+    +:+ +:+ +:+:+ +:+ :+:+:+  +:+     :+:     :+:+:+  +:+  +:+   +:+  +:+    +:+    +:+ +:+    +:+  
   +#+     +#++:++#++ +#++:++#           +#+    +:+ +#++:++#++ +#+  +:+  +#+ +#+ +:+ +#+     +#+     +#+ +:+ +#+ +#++:++#++: +#+    +#+    +:+ +#++:++#:    
  +#+     +#+    +#+ +#+                +#+    +#+ +#+    +#+ +#+       +#+ +#+  +#+#+#     +#+     +#+  +#+#+# +#+     +#+ +#+    +#+    :+: +#+    +#+    
 #+#     #+#    #+# #+#                #+#    #+# #+#    #+# #+#       #+# #+#   #+#+#     #+#     #+#   #+#+# #+#     #+# #+#    #+#    #+# #+#    #+#     
###     ###    ### ##########          ########  ###    ### ###       ### ###    #### ########### ###    #### ###     ### ###     ########  ###    ###      
`;

const NEON_GREEN = "#23ff00";
const NEON_GREEN_DIM = "#0fa000";

const AsciiHeader: React.FC = () => {
    const [color, setColor] = useState(NEON_GREEN);

    useEffect(() => {
        const intervalId = setInterval(() => {
            setColor(Math.random() > 0.5 ? NEON_GREEN : NEON_GREEN_DIM);
        }, Math.random() * 600 + 200);

        return () => clearInterval(intervalId);
    }, []);

    return (
        <div className="overflow-hidden flex">
            <div className="flex marquee">
                <pre 
                    className="flex-shrink-0 text-left text-[6px] sm:text-[9px] leading-tight p-2"
                    style={{ color: color, backgroundColor: 'black' }}
                >
                    {ORIGINAL_ASCII}
                </pre>
                <pre 
                    className="flex-shrink-0 text-left text-[6px] sm:text-[9px] leading-tight p-2"
                    style={{ color: color, backgroundColor: 'black' }}
                >
                    {ORIGINAL_ASCII}
                </pre>
            </div>
        </div>
    );
};

export default AsciiHeader;