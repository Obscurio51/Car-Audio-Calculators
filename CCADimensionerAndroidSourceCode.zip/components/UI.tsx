
import React, { useState, useEffect } from 'react';
import type { GroundingMethod } from '../types';

// --- Pulsing Logo Component ---
interface PulsingLogoProps {
  ascii: string;
}
export const PulsingLogo: React.FC<PulsingLogoProps> = ({ ascii }) => {
  const [isDim, setIsDim] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setIsDim(Math.random() < 0.4);
    }, 400);
    return () => clearInterval(timer);
  }, []);

  return (
    <pre className={`text-[8px] sm:text-xs md:text-sm leading-tight text-center transition-colors duration-200 ${isDim ? 'text-neon-green-dim' : 'text-neon-green'}`}>
      {ascii}
    </pre>
  );
};


// --- Pulsing Border Hook ---
const usePulsingBorder = (pulseRate: number = 460, probability: number = 0.25) => {
    const [isPulsing, setIsPulsing] = useState(false);
    useEffect(() => {
        const timer = setInterval(() => {
            setIsPulsing(Math.random() < probability);
        }, pulseRate);
        return () => clearInterval(timer);
    }, [pulseRate, probability]);
    return isPulsing;
};


// --- Neon Input Component ---
interface NeonInputProps {
  label: string;
  name: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}
export const NeonInput: React.FC<NeonInputProps> = ({ label, name, value, onChange }) => {
    const isPulsing = usePulsingBorder();
    return (
        <div>
            <label htmlFor={name} className="text-neon-green font-bold block mb-1 text-sm">{label}</label>
            <input
                id={name}
                name={name}
                type="text"
                value={value}
                onChange={onChange}
                className={`w-full bg-dark-input text-neon-green p-2 border transition-colors duration-100 text-lg ${isPulsing ? 'border-neon-green' : 'border-dark-border'}`}
            />
        </div>
    );
};

// --- Neon Select Component ---
interface NeonSelectProps {
    label: string;
    name: string;
    value: string | number;
    onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
    options: (string | { value: string | number; label: string })[];
}
export const NeonSelect: React.FC<NeonSelectProps> = ({ label, name, value, onChange, options }) => {
    const isPulsing = usePulsingBorder();
    return (
        <div>
            <label htmlFor={name} className="text-neon-green font-bold block mb-1 text-sm">{label}</label>
            <select
                id={name}
                name={name}
                value={value}
                onChange={onChange}
                className={`w-full bg-dark-input text-neon-green p-2 border transition-colors duration-100 text-lg appearance-none ${isPulsing ? 'border-neon-green' : 'border-dark-border'}`}
            >
                {options.map((opt, index) => {
                    if (typeof opt === 'string') {
                        return <option key={index} value={opt}>{opt}</option>;
                    }
                    return <option key={index} value={opt.value}>{opt.label}</option>;
                })}
            </select>
        </div>
    );
};


// --- Neon Radio Group Component ---
interface NeonRadioGroupProps {
    label: string;
    name: string;
    selectedValue: GroundingMethod;
    onChange: (value: GroundingMethod) => void;
    options: { value: GroundingMethod; label: string }[];
}
export const NeonRadioGroup: React.FC<NeonRadioGroupProps> = ({ label, name, selectedValue, onChange, options }) => {
    return (
        <div>
            <span className="text-neon-green font-bold block mb-1 text-sm">{label}</span>
            <div className="space-y-1">
                {options.map(opt => (
                     <label key={opt.value} className="flex items-center space-x-2 cursor-pointer text-neon-green">
                        <input
                            type="radio"
                            name={name}
                            value={opt.value}
                            checked={selectedValue === opt.value}
                            onChange={() => onChange(opt.value)}
                            className="hidden"
                        />
                        <span className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${selectedValue === opt.value ? 'border-neon-green' : 'border-neon-green-dim'}`}>
                          {selectedValue === opt.value && <span className="w-2 h-2 rounded-full bg-neon-green"></span>}
                        </span>
                        <span>{opt.label}</span>
                    </label>
                ))}
            </div>
        </div>
    );
};

// --- Neon Button Component ---
interface NeonButtonProps {
    text: string;
    onClick: () => void;
}
export const NeonButton: React.FC<NeonButtonProps> = ({ text, onClick }) => {
    return (
        <button
            onClick={onClick}
            className="w-full bg-dark-input text-neon-green font-bold text-lg border-2 border-dark-border p-2 transition-all duration-150 hover:border-neon-green-dim focus:border-neon-green active:bg-dark-border"
        >
            {text}
        </button>
    );
};
