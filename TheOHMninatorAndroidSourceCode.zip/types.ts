
export interface Fraction {
  num: number;
  den: number;
}

export type ExpressionTree = ['leaf', Fraction] | ['S' | 'P', ExpressionTree, ExpressionTree];

export interface CalculationResult {
  speakers: Fraction[];
  expr: string;
  value: number;
  tree: ExpressionTree;
}

export interface WorkerMessage {
  type: 'progress' | 'status' | 'result' | 'error' | 'done';
  payload: any;
}
