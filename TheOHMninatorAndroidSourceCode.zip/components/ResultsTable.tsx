
import React from 'react';
import type { CalculationResult, Fraction } from '../types';

interface ResultsTableProps {
  results: CalculationResult[];
  selectedIndex: number | null;
  onSelect: (index: number) => void;
}

const formatFraction = (f: Fraction): string => {
    const val = f.num / f.den;
    return Math.abs(val - Math.round(val)) < 1e-9 ? String(Math.round(val)) : val.toString();
};

const ResultsTable: React.FC<ResultsTableProps> = ({ results, selectedIndex, onSelect }) => {
    return (
        <div className="bg-[#001100] border border-[#003300] flex-1 overflow-auto">
            <table className="w-full text-sm text-left">
                <thead className="sticky top-0 bg-[#002200]">
                    <tr>
                        <th className="p-2 w-1/4">Speakers</th>
                        <th className="p-2 w-1/2">Expression</th>
                        <th className="p-2 w-1/4">Value (Ω)</th>
                    </tr>
                </thead>
                <tbody>
                    {results.map((r, idx) => (
                        <tr
                            key={idx}
                            onClick={() => onSelect(idx)}
                            className={`cursor-pointer transition-colors ${selectedIndex === idx ? 'bg-[#002200]' : 'hover:bg-[#001a00]'}`}
                        >
                            <td className="p-2 align-top break-all">{r.speakers.map(formatFraction).join(', ')}</td>
                            <td className="p-2 align-top break-all">{r.expr}</td>
                            <td className="p-2 align-top">{r.value.toFixed(6)}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ResultsTable;
