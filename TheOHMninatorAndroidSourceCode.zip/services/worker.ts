
// This script is designed to be run in a Web Worker.
// It is self-contained and includes all necessary logic for the calculation.

// --- Self-contained Fraction, Memoization, and Combination logic ---
const F_PRECISION = 1e-9;

function gcd(a, b) {
  return b === 0 ? a : gcd(b, a % b);
}

function createFraction(n, d = 1) {
  if (d === 0) throw new Error("Denominator cannot be zero.");
  const common = gcd(Math.abs(n), Math.abs(d));
  const num = (d > 0 ? 1 : -1) * n / common;
  const den = Math.abs(d) / common;
  return { num, den };
}

function parseValue(v) {
    const s = String(v);
    if (s.includes('/')) {
      const parts = s.split('/');
      return createFraction(parseInt(parts[0], 10), parseInt(parts[1], 10));
    }
    if (s.includes('.')) {
      let [intPart, decPart] = s.split('.');
      const den = Math.pow(10, decPart.length);
      const num = parseInt(intPart + decPart, 10);
      return createFraction(num, den);
    }
    return createFraction(parseInt(s, 10), 1);
}

function add(a, b) { return createFraction(a.num * b.den + b.num * a.den, a.den * b.den); }
function multiply(a, b) { return createFraction(a.num * b.num, a.den * b.den); }
function divide(a, b) { return createFraction(a.num * b.den, a.den * b.num); }
function toFloat(a) { return a.num / a.den; }

function series(a, b) { return add(a, b); }
function parallel(a, b) {
  const sum = add(a,b);
  if (sum.num === 0) return createFraction(0, 1);
  return divide(multiply(a, b), sum);
}

const memoize = (fn) => {
  const cache = new Map();
  return ((...args) => {
    const key = JSON.stringify(args);
    if (cache.has(key)) {
      return cache.get(key);
    }
    const result = fn(...args);
    cache.set(key, result);
    return result;
  });
};

const canonicalKey = (fracList) => JSON.stringify(fracList.slice().sort((a,b) => toFloat(a) - toFloat(b)));

const reachableValuesForKey = memoize((key) => {
  const state = JSON.parse(key);
  if (state.length === 1) {
    return new Set([state[0]]);
  }
  const results = new Set();
  const n = state.length;
  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      const a = state[i];
      const b = state[j];
      const rest = state.filter((_, k) => k !== i && k !== j);
      
      const s = series(a, b);
      const keyS = canonicalKey([...rest, s]);
      reachableValuesForKey(keyS).forEach(val => results.add(val));
      
      const p = parallel(a, b);
      const keyP = canonicalKey([...rest, p]);
      reachableValuesForKey(keyP).forEach(val => results.add(val));
    }
  }
  return results;
});

const replaceOneLeaf = (node, leafValue, replacementNode) => {
    const [type, left, right] = node;
    if (type === 'leaf') {
        const val = left;
        if (Math.abs(toFloat(val) - toFloat(leafValue)) < F_PRECISION) {
            return replacementNode;
        }
        return null;
    }
    const newLeft = replaceOneLeaf(left, leafValue, replacementNode);
    if (newLeft) return [type, newLeft, right];
    const newRight = replaceOneLeaf(right, leafValue, replacementNode);
    if (newRight) return [type, left, newRight];
    return null;
};

const findExprForExactValue = memoize((key, target) => {
  const state = JSON.parse(key);
  if (state.length === 1) {
    if (Math.abs(toFloat(state[0]) - toFloat(target)) < F_PRECISION) {
      return ['leaf', state[0]];
    }
    return null;
  }
  const n = state.length;
  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      const a = state[i];
      const b = state[j];
      const rest = state.filter((_, k) => k !== i && k !== j);
      
      const s = series(a, b);
      const keyS = canonicalKey([...rest, s]);
      const reachableS = Array.from(reachableValuesForKey(keyS));
      if (reachableS.some(v => Math.abs(toFloat(v) - toFloat(target)) < F_PRECISION)) {
          const sub = findExprForExactValue(keyS, target);
          if (sub) {
              const replaced = replaceOneLeaf(sub, s, ['S', ['leaf', a], ['leaf', b]]);
              if (replaced) return replaced;
          }
      }
      
      const p = parallel(a, b);
      const keyP = canonicalKey([...rest, p]);
      const reachableP = Array.from(reachableValuesForKey(keyP));
      if (reachableP.some(v => Math.abs(toFloat(v) - toFloat(target)) < F_PRECISION)) {
          const sub = findExprForExactValue(keyP, target);
          if (sub) {
              const replaced = replaceOneLeaf(sub, p, ['P', ['leaf', a], ['leaf', b]]);
              if (replaced) return replaced;
          }
      }
    }
  }
  return null;
});

function* combinationsWithReplacement(pool, r) {
    if (r === 0) {
        yield [];
        return;
    }
    for (let i = 0; i < pool.length; i++) {
        for (const comb of combinationsWithReplacement(pool.slice(i), r - 1)) {
            yield [pool[i], ...comb];
        }
    }
}

function multisetsWithMandatory(values, minN, maxN, mandatory) {
    // FIX: Explicitly type `out` as a Set of strings to resolve type inference issue with JSON.parse.
    const out = new Set<string>();
    const mandLen = mandatory.length;
    for (let n = Math.max(minN, mandLen); n <= maxN; n++) {
        const r = n - mandLen;
        if (r < 0) continue;
        for (const comb of combinationsWithReplacement(values, r)) {
            const full = [...mandatory, ...comb].sort((a,b) => toFloat(a) - toFloat(b));
            out.add(JSON.stringify(full));
        }
    }
    return Array.from(out).map(s => JSON.parse(s)).sort((a,b) => a.length - b.length || (toFloat(a[0]) - toFloat(b[0])));
}

function exprValueAndStr(node) {
    const [type, left, right] = node;
    if (type === 'leaf') {
        const v = left;
        const fv = toFloat(v);
        const formatted = Math.abs(fv - Math.round(fv)) < F_PRECISION ? String(Math.round(fv)) : fv.toString();
        return [v, formatted];
    }
    const [aVal, aStr] = exprValueAndStr(left);
    const [bVal, bStr] = exprValueAndStr(right);
    const val = type === 'S' ? series(aVal, bVal) : parallel(aVal, bVal);
    return [val, '(' + aStr + ' ' + type + ' ' + bStr + ')'];
}

function harmonicParallelMin(vals) {
  let s = 0.0;
  for (const v of vals) {
      try { s += 1.0 / toFloat(v); } catch {}
  }
  return s > 0 ? 1.0 / s : 0.0;
}

// --- Main Worker Logic ---
let isCancelled = false;

self.onmessage = (e) => {
  if (e.data.type === 'cancel') {
    isCancelled = true;
    return;
  }

  isCancelled = false;
  const { allValues, mandatory, minRes, maxRes, target, tol, fullVersion } = e.data;
  
  const targetFrac = parseValue(target);
  const allValuesFrac = allValues.map(parseValue);
  const mandatoryFrac = mandatory.map(parseValue);

  try {
    const multisets = multisetsWithMandatory(allValuesFrac, minRes, maxRes, mandatoryFrac);
    const total = multisets.length;
    if (total === 0) {
      self.postMessage({ type: 'error', payload: 'No combinations generated with the given parameters.' });
      self.postMessage({ type: 'done' });
      return;
    }
    
    let resultsCount = 0;
    
    for (let i = 0; i < total; i++) {
      if (isCancelled) break;
      const ms = multisets[i];

      if (i % 5 === 0 || i === 0 || i === total - 1) {
        self.postMessage({ type: 'progress', payload: { processed: i + 1, total } });
        self.postMessage({ type: 'status', payload: 'Checking ' + (i + 1) + '/' + total + '...' });
      }

      const numericList = ms.map(toFloat);
      const maxPossible = numericList.reduce((sum, v) => sum + v, 0);
      const minPossible = harmonicParallelMin(ms);
      if (toFloat(targetFrac) + tol < minPossible - F_PRECISION || toFloat(targetFrac) - tol > maxPossible + F_PRECISION) {
          continue;
      }

      const key = canonicalKey(ms);
      try {
          const reachable = Array.from(reachableValuesForKey(key));
          const matches = reachable.filter(v => Math.abs(toFloat(v) - toFloat(targetFrac)) <= tol);

          if (matches.length > 0) {
              const chosen = matches.reduce((best, curr) => 
                  Math.abs(toFloat(curr) - toFloat(targetFrac)) < Math.abs(toFloat(best) - toFloat(targetFrac)) ? curr : best
              );
              
              const node = findExprForExactValue(key, chosen);
              if (node) {
                  const [val, expr] = exprValueAndStr(node);
                  resultsCount++;
                  self.postMessage({ type: 'result', payload: { speakers: ms, expr, value: toFloat(val), tree: node } });
                  if (!fullVersion && resultsCount >= 40) {
                      break;
                  }
              }
          }
      } catch (err) {
          // Recursion depth or other errors, skip this multiset
          continue;
      }
    }
    self.postMessage({ type: 'done' });
  } catch (err) {
    self.postMessage({ type: 'error', payload: err.message });
    self.postMessage({ type: 'done' });
  }
};