import React, { useRef, useMemo, useState, useEffect } from 'react';
import type { CalculationResult, ExpressionTree, Fraction } from '../types';

interface DiagramNode {
  id: string;
  type: 'leaf' | 'S' | 'P';
  value?: Fraction;
  children?: [DiagramNode, DiagramNode];
  leafCount: number;
}

interface NodePosition {
  id: string;
  x: number;
  y: number;
  label: string;
  isLeaf: boolean;
  watts?: number;
  impedanceStr?: string;
  node: DiagramNode;
}

interface LinePosition {
  key: string;
  x1: number, y1: number;
  x2: number, y2: number;
  type: 'S' | 'P';
}

const toFloat = (f: Fraction) => f.num / f.den;

const Diagram: React.FC<{ result: CalculationResult | null; inputPower: number }> = ({ result, inputPower }) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const [viewBox, setViewBox] = useState({ x: 0, y: 0, width: 100, height: 100 });
  const [isPanning, setIsPanning] = useState(false);
  const startPointRef = useRef({ x: 0, y: 0 });
  const pinchDistRef = useRef<number | null>(null);

  const data = useMemo(() => {
    if (!result) return null;

    // 1. Convert ExpressionTree to a tree with unique IDs and calculate leaf counts
    let nodeIdCounter = 0;
    const convertToDiagramTree = (node: ExpressionTree): DiagramNode => {
        const id = `node-${nodeIdCounter++}`;
        const [type, left, right] = node;
        if (type === 'leaf') {
            return { id, type: 'leaf', value: left, leafCount: 1 };
        }
        const leftChild = convertToDiagramTree(left);
        const rightChild = convertToDiagramTree(right);
        return {
            id,
            type,
            children: [leftChild, rightChild],
            leafCount: leftChild.leafCount + rightChild.leafCount,
        };
    };
    const diagramTree = convertToDiagramTree(result.tree);

    // 2. Assign positions using leaf counts for weighting
    const positions = new Map<string, {x: number, y: number}>();
    const assignPositions = (node: DiagramNode, depth = 0, xOffset = 0): number => {
      let x;
      if (node.type === 'leaf') {
        x = xOffset;
      } else {
        const [left, right] = node.children!;
        const xLeft = assignPositions(left, depth + 1, xOffset);
        const xRight = assignPositions(right, depth + 1, xOffset + left.leafCount);
        x = (xLeft + xRight) / 2.0;
      }
      positions.set(node.id, { x, y: -depth });
      return x;
    };
    assignPositions(diagramTree);

    // 3. Calculate impedance and power for each node
    const getImpedance = (node: DiagramNode): number => {
        if (node.type === 'leaf') return toFloat(node.value!);
        const [left, right] = node.children!;
        const a = getImpedance(left);
        const b = getImpedance(right);
        if (node.type === 'S') return a + b;
        if (a === 0 || b === 0) return 0;
        return 1.0 / (1.0 / a + 1.0 / b);
    };

    const totalR = getImpedance(diagramTree) || 1e-9;
    const vIn = Math.sqrt(inputPower * totalR);
    const leafPowers = new Map<string, number>();

    const computePower = (node: DiagramNode, V: number) => {
        if (node.type === 'leaf') {
            const R = toFloat(node.value!) || 1e-9;
            leafPowers.set(node.id, (V * V) / R);
            return;
        }
        const [left, right] = node.children!;
        if (node.type === 'S') {
            const aR = getImpedance(left);
            const bR = getImpedance(right);
            const totalBranchR = aR + bR || 1e-9;
            const I = V / totalBranchR;
            computePower(left, I * aR);
            computePower(right, I * bR);
        } else {
            computePower(left, V);
            computePower(right, V);
        }
    };
    if (inputPower > 0 && isFinite(vIn)) {
        computePower(diagramTree, vIn);
    }
    
    // 4. Build final render data (nodes and lines)
    const nodes: NodePosition[] = [];
    const lines: LinePosition[] = [];
    const buildRenderData = (node: DiagramNode) => {
        const {x, y} = positions.get(node.id)!;
        
        nodes.push({
            id: node.id, x, y,
            label: node.type === 'leaf' ? '' : node.type,
            isLeaf: node.type === 'leaf',
            watts: leafPowers.get(node.id),
            impedanceStr: node.type === 'leaf' ? `${toFloat(node.value!).toString()} Ω` : undefined,
            node
        });

        if (node.type !== 'leaf') {
            const [left, right] = node.children!;
            const {x: cx1, y: cy1} = positions.get(left.id)!;
            const {x: cx2, y: cy2} = positions.get(right.id)!;
            lines.push({key: `${node.id}-l`, x1: x, y1: y, x2: cx1, y2: cy1, type: node.type});
            lines.push({key: `${node.id}-r`, x1: x, y1: y, x2: cx2, y2: cy2, type: node.type});
            buildRenderData(left);
            buildRenderData(right);
        }
    };
    buildRenderData(diagramTree);
    
    const allX = nodes.map(n => n.x);
    const allY = nodes.map(n => n.y);
    const minX = Math.min(...allX);
    const maxX = Math.max(...allX);
    const minY = Math.min(...allY);
    const maxY = Math.max(...allY);

    return { nodes, lines, minX, maxX, minY, maxY, title: result.expr };
  }, [result, inputPower]);

  const FONT_SIZE = 10;
  const PADDING = 40;
  const BOX_WIDTH = 60;
  const BOX_HEIGHT = 40;
  const UNIT_WIDTH = BOX_WIDTH + 20;
  const UNIT_HEIGHT = BOX_HEIGHT + 30;

  useEffect(() => {
    if (data) {
      const { minX, maxX, minY, maxY } = data;
      const width = (maxX - minX) * UNIT_WIDTH + BOX_WIDTH + PADDING * 2;
      const height = (maxY - minY) * UNIT_HEIGHT + BOX_HEIGHT + PADDING * 2;
      const x = -PADDING;
      const y = minY * UNIT_HEIGHT - PADDING - BOX_HEIGHT / 2;
      setViewBox({ x, y, width, height });
    }
  }, [data]);

  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsPanning(true);
    startPointRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isPanning || !svgRef.current) return;
    e.preventDefault();
    const svg = svgRef.current;
    const rect = svg.getBoundingClientRect();

    const dx = (e.clientX - startPointRef.current.x) * (viewBox.width / rect.width);
    const dy = (e.clientY - startPointRef.current.y) * (viewBox.height / rect.height);
    
    setViewBox(prev => ({
        ...prev,
        x: prev.x - dx,
        y: prev.y - dy,
    }));

    startPointRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUpOrLeave = () => {
    setIsPanning(false);
  };
  
  const getTouchDistance = (touches: React.TouchList) => {
    const touch1 = touches[0];
    const touch2 = touches[1];
    return Math.hypot(touch1.clientX - touch2.clientX, touch1.clientY - touch2.clientY);
  };

  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length === 2) { // Pinch zoom
      e.preventDefault();
      pinchDistRef.current = getTouchDistance(e.touches);
      setIsPanning(false);
    } else if (e.touches.length === 1) { // Pan
      e.preventDefault();
      const touch = e.touches[0];
      startPointRef.current = { x: touch.clientX, y: touch.clientY };
      setIsPanning(true);
      pinchDistRef.current = null;
    }
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!svgRef.current) return;

    if (e.touches.length === 2 && pinchDistRef.current !== null) { // Zooming
      e.preventDefault();
      const newDist = getTouchDistance(e.touches);
      const zoomFactor = pinchDistRef.current / newDist;
      pinchDistRef.current = newDist;

      const svg = svgRef.current;
      const rect = svg.getBoundingClientRect();
      const touch1 = e.touches[0];
      const touch2 = e.touches[1];
      const midX = (touch1.clientX + touch2.clientX) / 2 - rect.left;
      const midY = (touch1.clientY + touch2.clientY) / 2 - rect.top;

      const point = {
        x: (midX / rect.width) * viewBox.width + viewBox.x,
        y: (midY / rect.height) * viewBox.height + viewBox.y,
      };
      
      const newWidth = viewBox.width * zoomFactor;
      const newHeight = viewBox.height * zoomFactor;

      setViewBox({
        x: point.x - (midX / rect.width) * newWidth,
        y: point.y - (midY / rect.height) * newHeight,
        width: newWidth,
        height: newHeight,
      });

    } else if (e.touches.length === 1 && isPanning) { // Panning
      e.preventDefault();
      const svg = svgRef.current;
      const rect = svg.getBoundingClientRect();
      const touch = e.touches[0];
      const dx = (touch.clientX - startPointRef.current.x) * (viewBox.width / rect.width);
      const dy = (touch.clientY - startPointRef.current.y) * (viewBox.height / rect.height);
      
      setViewBox(prev => ({ ...prev, x: prev.x - dx, y: prev.y - dy }));
      startPointRef.current = { x: touch.clientX, y: touch.clientY };
    }
  };

  const handleTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    pinchDistRef.current = null;
    if (e.touches.length < 2) {
      setIsPanning(false);
    }
  };

  if (!data || !result) {
    return (
      <div className="bg-[#000000] border-2 border-[#23ff00] h-full flex items-center justify-center p-4">
        <p className="text-[#0fa000]">Select a result to see the diagram</p>
      </div>
    );
  }
  
  const { nodes, lines, minX, title } = data;
  
  const transformX = (x: number) => (x - minX) * UNIT_WIDTH;
  const transformY = (y: number) => y * UNIT_HEIGHT;

  return (
    <div className="bg-[#000000] border-2 border-[#23ff00] h-full flex flex-col p-2 overflow-hidden">
        <p className="text-center p-2 text-sm truncate flex-shrink-0">{title}</p>
        <div 
            className="flex-1 w-full h-full" 
            style={{minHeight: 0, cursor: isPanning ? 'grabbing' : 'grab', touchAction: 'none'}}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUpOrLeave}
            onMouseLeave={handleMouseUpOrLeave}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
        >
             <svg 
                ref={svgRef} 
                className="w-full h-full" 
                viewBox={`${viewBox.x} ${viewBox.y} ${viewBox.width} ${viewBox.height}`} 
                preserveAspectRatio="xMidYMid meet"
             >
                {lines.map(l => (
                    <line key={l.key} 
                          x1={transformX(l.x1)} y1={transformY(l.y1)} 
                          x2={transformX(l.x2)} y2={transformY(l.y2)} 
                          stroke={l.type === 'S' ? '#23ff00' : 'white'} 
                          strokeWidth="1.5" />
                ))}
                {nodes.map(n => (
                    <g key={n.id} transform={`translate(${transformX(n.x)}, ${transformY(n.y)})`}>
                        <rect x={-BOX_WIDTH/2} y={-BOX_HEIGHT/2} width={BOX_WIDTH} height={BOX_HEIGHT} fill="#23ff00" rx="3" />
                         <text
                            fill="black"
                            fontSize={FONT_SIZE}
                            textAnchor="middle"
                            dominantBaseline="middle"
                        >
                            {n.isLeaf ?
                                <>
                                    <tspan x="0" dy="-0.4em">{n.impedanceStr}</tspan>
                                    {typeof n.watts === 'number' && isFinite(n.watts) && <tspan x="0" dy="1.2em">{n.watts.toFixed(1)}W</tspan>}
                                </>
                                : <tspan>{n.label}</tspan>
                            }
                        </text>
                    </g>
                ))}
            </svg>
        </div>
    </div>
  );
};

export default Diagram;