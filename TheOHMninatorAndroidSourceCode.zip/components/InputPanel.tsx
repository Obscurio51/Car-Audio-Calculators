import React from 'react';

const STD_VALUES = [0.5, 1, 2, 3, 4, 6, 8, 16];

interface InputPanelProps {
  stdValues: number[];
  setStdValues: React.Dispatch<React.SetStateAction<number[]>>;
  customValues: string;
  setCustomValues: (value: string) => void;
  mandatoryValues: string;
  setMandatoryValues: (value: string) => void;
  minRes: number;
  setMinRes: (value: number) => void;
  maxRes: number;
  setMaxRes: (value: number) => void;
  target: string;
  setTarget: (value: string) => void;
  tolerance: string;
  setTolerance: (value: string) => void;
  power: string;
  setPower: (value: string) => void;
  fullVersion: boolean;
  setFullVersion: (value: boolean) => void;
  isLoading: boolean;
  status: string;
  progress: { processed: number, total: number };
  onCalculate: () => void;
  onCancel: () => void;
  onClear: () => void;
}

const Label: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <label className="text-[#23ff00] bg-[#070707] text-sm">{children}</label>
);

const Input: React.FC<React.InputHTMLAttributes<HTMLInputElement>> = (props) => (
    <input
        {...props}
        className={`bg-[#001100] text-[#23ff00] border border-[#003300] p-2 w-full focus:outline-none focus:border-[#23ff00] transition-colors ${props.className || ''}`}
    />
);

const Button: React.FC<{ onClick: () => void, children: React.ReactNode, disabled?: boolean, primary?: boolean }> = ({ onClick, children, disabled, primary }) => (
    <button
        onClick={onClick}
        disabled={disabled}
        className={`bg-[#001100] text-[#23ff00] border-0 p-2 w-full transition-all duration-200 
            ${primary ? 'font-bold text-lg' : ''}
            ${disabled ? 'text-[#0fa000] cursor-not-allowed' : 'hover:bg-[#002200] hover:text-white'}`}
    >
        {children}
    </button>
);

const Checkbox: React.FC<{ label: string, checked: boolean, onChange: (checked: boolean) => void }> = ({ label, checked, onChange }) => (
    <label className="flex items-center space-x-2 cursor-pointer text-[#23ff00]">
        <input
            type="checkbox"
            checked={checked}
            onChange={(e) => onChange(e.target.checked)}
            className="form-checkbox appearance-none h-4 w-4 border border-[#003300] bg-[#001100] rounded-sm checked:bg-[#23ff00] checked:border-transparent focus:outline-none"
        />
        <span>{label}</span>
    </label>
);

const NumberInput: React.FC<{
  value: number;
  onChange: (value: number) => void;
  min: number;
  max: number;
}> = ({ value, onChange, min, max }) => {
    const handleIncrement = () => {
        onChange(Math.min(max, value + 1));
    };

    const handleDecrement = () => {
        onChange(Math.max(min, value - 1));
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const val = parseInt(e.target.value, 10);
        if (e.target.value === '') {
            onChange(min);
            return;
        }
        if (!isNaN(val)) {
            onChange(Math.max(min, Math.min(max, val)));
        }
    };

    return (
        <div className="relative">
            <Input
                type="number"
                value={value}
                onChange={handleChange}
                min={min}
                max={max}
                className="custom-number-input pr-10"
            />
            <div className="absolute right-0 top-0 bottom-0 w-8 grid grid-rows-2 border-l border-[#003300]">
                <button
                    onClick={handleIncrement}
                    disabled={value >= max}
                    className="flex items-center justify-center text-lg text-[#23ff00] hover:bg-[#002200] disabled:text-[#0fa000] disabled:cursor-not-allowed transition-colors border-b border-[#003300]"
                    aria-label="Increase value"
                >
                    ▲
                </button>
                <button
                    onClick={handleDecrement}
                    disabled={value <= min}
                    className="flex items-center justify-center text-lg text-[#23ff00] hover:bg-[#002200] disabled:text-[#0fa000] disabled:cursor-not-allowed transition-colors"
                    aria-label="Decrease value"
                >
                    ▼
                </button>
            </div>
        </div>
    );
};


const InputPanel: React.FC<InputPanelProps> = ({
  stdValues, setStdValues, customValues, setCustomValues, mandatoryValues, setMandatoryValues,
  minRes, setMinRes, maxRes, setMaxRes, target, setTarget, tolerance, setTolerance, power, setPower,
  fullVersion, setFullVersion, isLoading, status, progress, onCalculate, onCancel, onClear
}) => {

    const handleStdChange = (value: number, isChecked: boolean) => {
        if (isChecked) {
            setStdValues([...stdValues, value]);
        } else {
            setStdValues(stdValues.filter(v => v !== value));
        }
    };

    const progressPct = progress.total > 0 ? (progress.processed / progress.total) * 100 : 0;
    
    return (
        <div className="bg-[#070707] p-4 flex flex-col space-y-4 border border-[#003300] h-full overflow-y-auto">
            <div>
                <Label>Standard Values:</Label>
                <div className="grid grid-cols-4 gap-2 mt-1">
                    {STD_VALUES.map(v => (
                        <Checkbox key={v} label={`${v} Ω`} checked={stdValues.includes(v)} onChange={(c) => handleStdChange(v, c)} />
                    ))}
                </div>
            </div>
            <div>
                <Label>Custom Values (e.g., 2.2, 5.6):</Label>
                <Input value={customValues} onChange={e => setCustomValues(e.target.value)} />
            </div>
            <div>
                <Label>Mandatory Resistances (e.g., 4, 4):</Label>
                <Input value={mandatoryValues} onChange={e => setMandatoryValues(e.target.value)} />
            </div>
            <div className="flex space-x-4 items-center">
                <div className="flex-1">
                    <Label>Min Speakers:</Label>
                    <NumberInput value={minRes} onChange={setMinRes} min={2} max={12} />
                </div>
                <div className="flex-1">
                    <Label>Max Speakers:</Label>
                    <NumberInput value={maxRes} onChange={setMaxRes} min={2} max={12} />
                </div>
            </div>
            <div>
                <Label>Target (Ω):</Label>
                <Input value={target} onChange={e => setTarget(e.target.value)} />
            </div>
            <div>
                <Label>Tolerance (Ω):</Label>
                <Input value={tolerance} onChange={e => setTolerance(e.target.value)} />
            </div>
            <div>
                <Label>Input Power (W):</Label>
                <Input value={power} onChange={e => setPower(e.target.value)} />
            </div>
            <div className="pt-2">
                <Checkbox label="Full version (off = max 40 results)" checked={fullVersion} onChange={setFullVersion} />
            </div>
            <div className="flex-grow"></div>
            <div className="space-y-2 pt-4">
                <p className="text-sm italic h-5">{status}</p>
                <div className="w-full bg-[#001100] border border-[#003300] h-4">
                    <div className="bg-[#23ff00] h-full" style={{ width: `${progressPct}%` }}></div>
                </div>
                 <p className="text-xs text-right h-4">
                    {isLoading ? `${Math.round(progressPct)}% - ${progress.processed}/${progress.total}` : ''}
                </p>
                
                {isLoading && <Button onClick={onCancel}>Cancel</Button>}

                <Button onClick={onCalculate} disabled={isLoading} primary={!isLoading}>&gt;&gt;&gt; CALCULATE &lt;&lt;&lt;</Button>

                <div className="flex space-x-2">
                    <Button onClick={onClear} disabled={isLoading}>Clear</Button>
                </div>
            </div>
        </div>
    );
};

export default InputPanel;