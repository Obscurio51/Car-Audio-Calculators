
export type AmplifierClass = "A" | "AB" | "D" | "T" | "G" | "H";
export type GroundingMethod = "battery" | "chassis";

export interface FormState {
  length: string;
  power: string;
  voltageDrop: string;
  nominalVoltage: string;
  batteryCapacity: string;
  alternatorCurrent: string;
  peukert: string;
  ampClass: AmplifierClass;
  usage: number;
  grounding: GroundingMethod;
}
