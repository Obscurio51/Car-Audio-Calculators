import React, { useState, useEffect, useRef, useCallback } from 'react';
import InputPanel from './components/InputPanel';
import ResultsTable from './components/ResultsTable';
import Diagram from './components/Diagram';
import AsciiHeader from './components/AsciiHeader';
import type { CalculationResult, WorkerMessage } from './types';
import Worker from './services/worker?worker';

const App: React.FC = () => {
    const [stdValues, setStdValues] = useState<number[]>([4]);
    const [customValues, setCustomValues] = useState('');
    const [mandatoryValues, setMandatoryValues] = useState('4,4');
    const [minRes, setMinRes] = useState(2);
    const [maxRes, setMaxRes] = useState(8);
    const [target, setTarget] = useState('2.0');
    const [tolerance, setTolerance] = useState('0.05');
    const [power, setPower] = useState('100');
    const [fullVersion, setFullVersion] = useState(false);

    const [results, setResults] = useState<CalculationResult[]>([]);
    const [selectedIndex, setSelectedIndex] = useState<number | null>(null);

    const [isLoading, setIsLoading] = useState(false);
    const [status, setStatus] = useState("Ready.");
    const [progress, setProgress] = useState({ processed: 0, total: 0 });
    
    const workerRef = useRef<Worker | null>(null);
    const diagramContainerRef = useRef<HTMLDivElement>(null);

    const handleWorkerMessage = useCallback((event: MessageEvent<WorkerMessage>) => {
        const { type, payload } = event.data;
        switch (type) {
            case 'progress':
                setProgress(payload);
                break;
            case 'status':
                setStatus(payload);
                break;
            case 'result':
                setResults(prev => {
                    const newResults = [...prev, payload];
                    // Select the first result as it arrives
                    if (newResults.length === 1) {
                        setSelectedIndex(0);
                    }
                    return newResults;
                });
                break;
            case 'error':
                setStatus(`Error: ${payload}`);
                setIsLoading(false);
                break;
            case 'done':
                setIsLoading(false);
                break;
        }
    }, []);

    useEffect(() => {
        const worker = new Worker();
        workerRef.current = worker;

        worker.onmessage = handleWorkerMessage;

        return () => {
            worker.terminate();
        };
    }, [handleWorkerMessage]);
    
    useEffect(() => {
        if (isLoading) {
            if (progress.processed > 0) {
                 setStatus(`Found ${results.length} solutions... (${Math.round((progress.processed/progress.total)*100)}%)`);
            }
        } else if (results.length > 0) {
            setStatus(`Found ${results.length} solutions.`);
        }
    }, [results, isLoading, progress]);

    const handleCalculate = useCallback(() => {
        const allStd = stdValues.map(String);
        const allCustom = customValues.split(',').map(s => s.trim()).filter(Boolean);
        const allValues = [...new Set([...allStd, ...allCustom])];
        if (allValues.length === 0) {
            setStatus("Error: Select or enter at least one value.");
            return;
        }

        setResults([]);
        setSelectedIndex(null);
        setIsLoading(true);
        setProgress({ processed: 0, total: 0 });
        setStatus("Preparing calculation...");

        workerRef.current?.postMessage({
            type: 'start',
            allValues,
            mandatory: mandatoryValues.split(',').map(s => s.trim()).filter(Boolean),
            minRes,
            maxRes,
            target,
            tol: parseFloat(tolerance) || 0.05,
            fullVersion,
        });
    }, [stdValues, customValues, mandatoryValues, minRes, maxRes, target, tolerance, fullVersion]);

    const handleCancel = useCallback(() => {
        workerRef.current?.postMessage({ type: 'cancel' });
        setIsLoading(false);
        setStatus("Calculation cancelled.");
    }, []);

    const handleClear = useCallback(() => {
        setResults([]);
        setSelectedIndex(null);
        setProgress({ processed: 0, total: 0 });
        setStatus("Results cleared.");
    }, []);

    const handleSelectResult = useCallback((index: number) => {
        setSelectedIndex(index);
        // On mobile, scroll to the diagram when a result is selected for better UX
        if (window.innerWidth < 768 && diagramContainerRef.current) {
            diagramContainerRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, []);

    const selectedResult = selectedIndex !== null ? results[selectedIndex] : null;

    return (
        <div className="flex flex-col min-h-screen bg-black text-xs font-mono">
            <AsciiHeader />
            <main className="flex-grow flex flex-col md:flex-row p-2 gap-2">
                <div className="w-full md:w-[380px] md:flex-shrink-0 flex flex-col">
                    <InputPanel
                        stdValues={stdValues} setStdValues={setStdValues}
                        customValues={customValues} setCustomValues={setCustomValues}
                        mandatoryValues={mandatoryValues} setMandatoryValues={setMandatoryValues}
                        minRes={minRes} setMinRes={setMinRes}
                        maxRes={maxRes} setMaxRes={setMaxRes}
                        target={target} setTarget={setTarget}
                        tolerance={tolerance} setTolerance={setTolerance}
                        power={power} setPower={setPower}
                        fullVersion={fullVersion} setFullVersion={setFullVersion}
                        isLoading={isLoading} status={status} progress={progress}
                        onCalculate={handleCalculate} onCancel={handleCancel}
                        onClear={handleClear}
                    />
                </div>
                <div className="flex-grow flex flex-col gap-2 border border-[#003300] p-2 bg-[#070707]">
                    <div className="min-h-[300px] md:min-h-0 md:flex-1 flex flex-col">
                      <ResultsTable results={results} selectedIndex={selectedIndex} onSelect={handleSelectResult} />
                    </div>
                    <div ref={diagramContainerRef} className="min-h-[400px] md:min-h-0 md:flex-1 flex flex-col">
                      <Diagram result={selectedResult} inputPower={parseFloat(power) || 0} />
                    </div>
                </div>
            </main>
        </div>
    );
};

export default App;