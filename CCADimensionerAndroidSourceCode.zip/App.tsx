
import React, { useState, useCallback } from 'react';
import { ASCII_LOGO } from './constants';
import type { FormState, AmplifierClass, GroundingMethod } from './types';
import { NeonInput, NeonSelect, NeonRadioGroup, NeonButton, PulsingLogo } from './components/UI';

const App: React.FC = () => {
  const [form, setForm] = useState<FormState>({
    length: '5',
    power: '3000',
    voltageDrop: '0.5',
    nominalVoltage: '12.8',
    batteryCapacity: '80',
    alternatorCurrent: '120',
    peukert: '1.2',
    ampClass: 'D',
    usage: 40,
    grounding: 'chassis'
  });

  const [output, setOutput] = useState<string>('>>> Press "GENERATE (CALCULATE)" to start...');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const handleRadioChange = (value: GroundingMethod) => {
    setForm(prev => ({...prev, grounding: value}));
  };
  
  const calculate = useCallback(() => {
    try {
      const lunghezza = parseFloat(form.length.replace(",", "."));
      const potenza = parseFloat(form.power.replace(",", "."));
      const classe = form.ampClass;
      const delta_v = parseFloat(form.voltageDrop.replace(",", "."));
      const tensione = parseFloat(form.nominalVoltage.replace(",", "."));
      const capacita_batt = parseFloat(form.batteryCapacity.replace(",", "."));
      const alternatore_A = parseFloat(form.alternatorCurrent.replace(",", "."));
      const peukert = parseFloat(form.peukert.replace(",", "."));
      const utilizzo = form.usage / 100.0;

      const eff_dict: Record<AmplifierClass, number> = {"A":0.25, "AB":0.55, "D":0.85, "T":0.80, "G":0.70, "H":0.80};
      const eff = eff_dict[classe];
      
      const fattore_massa = form.grounding === "battery" ? 2.0 : 1.3;
      const lung_eff = lunghezza * fattore_massa;
      const rho = 0.0175; // copper resistivity
      const corrente = (potenza / (tensione * eff)) * utilizzo;

      if (corrente === 0) throw new Error("Current cannot be zero. Check inputs.");

      const r_max = delta_v / corrente;
      const sezione = (rho * lung_eff) / r_max;
      const metri_equivalenti = lung_eff;
      const farad = Math.round((potenza / 100) * 0.03 * 100) / 100;

      const autonomia = (capacita: number, corrente: number, k: number): number | string => {
        if (corrente <= 0) return "∞ (alternator sufficient)";
        const h_nom = 20.0;
        return h_nom * Math.pow((capacita / (corrente * h_nom)), k);
      };

      const formatta_autonomia = (ore: number | string): string => {
        if (typeof ore === 'string') return ore;
        if (ore <= 0) return "0 min";
        if (ore < 1) return `${(ore * 60).toFixed(0)} min`;
        const h = Math.floor(ore);
        const m = Math.round((ore - h) * 60);
        return `${h}h ${m}m`;
      };
      
      const corrente_12v = (potenza / (12 * eff)) * utilizzo;
      const autonomia_spento = formatta_autonomia(autonomia(capacita_batt, corrente_12v, peukert));
      const corrente_14v = (potenza / (14.4 * eff)) * utilizzo;
      let autonomia_acceso: string;
      if (alternatore_A >= corrente_14v) {
        autonomia_acceso = "∞ (alternator sufficient)";
      } else {
        const corrente_mancante = corrente_14v - alternatore_A;
        autonomia_acceso = formatta_autonomia(autonomia(capacita_batt, corrente_mancante, peukert));
      }

      const corrente_residua = alternatore_A - corrente;
      const residuo_msg = corrente_residua < 0 ? `✖ Alternator residual current: ${corrente_residua.toFixed(1)} A` :
                          corrente_residua < 20 ? `△ Alternator residual current: +${corrente_residua.toFixed(1)} A` :
                          `✔ Alternator residual current: +${corrente_residua.toFixed(1)} A`;
                          
      const margine = alternatore_A - corrente;
      const alt_msg = margine >= 40 ? "✔ Alternator adequate for the expected load." :
                      margine > 0 ? "△ Alternator near its limit: consider an upgrade or additional battery." :
                      "✖ Alternator insufficient: upgrade required, including its power cable.";

      const batt_msg = corrente < 60 ? "✔ Battery sufficient for the system." :
                       corrente <= 100 ? "△ High current draw: consider adding a second battery." :
                       "✖ Very high current: an additional battery is recommended.";

      const crest_factor = utilizzo > 0 ? 10 * Math.log10(1 / utilizzo) : 0;
      
      const spieg = "Note: 'Realistic Usage' is the percentage of time the amplifier delivers power.\nA lower value indicates more dynamic music and less average current draw.\n\n";
      
      const result = 
        `${spieg}` +
        `--- Calculation for REALISTIC USAGE = ${form.usage}% ---\n` +
        `Crest Factor ≈ ${crest_factor.toFixed(1)} dB\n` +
        `Amplifier Class: ${classe} (efficiency ${(eff * 100).toFixed(0)}%)\n` +
        `Estimated Current: ${corrente.toFixed(1)} A\n` +
        `Minimum theoretical section: ${sezione.toFixed(2)} mm²\n` +
        `Equivalent cable meters considered: ${metri_equivalenti.toFixed(1)} m\n\n` +
        `Recommended Capacitor: ${farad} F\n` +
        `(Based on total RMS power, independent of realistic usage)\n\n` +
        `Battery Efficiency (Peukert): ${peukert}\n` +
        `Battery Capacity: ${capacita_batt.toFixed(0)} Ah\n` +
        `Estimated autonomy (continuous full volume):\n` +
        ` - Engine off (12 V): ${autonomia_spento}\n` +
        ` - Engine on (14.4 V): ${autonomia_acceso}\n\n` +
        `${residuo_msg}\n` +
        `Alternator: ${alternatore_A.toFixed(0)} A nominal\n\n` +
        `${batt_msg}\n${alt_msg}`;
      
      setOutput(result);
    } catch (e) {
      if (e instanceof Error) {
        setOutput(`>>> ERROR: ${e.message}`);
      } else {
        setOutput(">>> An unknown error occurred.");
      }
    }
  }, [form]);

  return (
    <div className="bg-dark-bg text-neon-green font-mono min-h-screen p-4 flex flex-col items-center">
      <div className="w-full max-w-6xl">
        <PulsingLogo ascii={ASCII_LOGO} />

        <div className="flex flex-col md:flex-row gap-8 mt-4">
          {/* LEFT PANE */}
          <div className="flex-shrink-0 md:w-1/3 space-y-2">
            <NeonInput label="Positive cable length (one way, m):" name="length" value={form.length} onChange={handleInputChange} />
            <NeonInput label="Total RMS power (W):" name="power" value={form.power} onChange={handleInputChange} />
            <NeonInput label="Admitted voltage drop (V) (usually 0.3–0.5):" name="voltageDrop" value={form.voltageDrop} onChange={handleInputChange} />
            <NeonInput label="Nominal voltage (V):" name="nominalVoltage" value={form.nominalVoltage} onChange={handleInputChange} />
            <NeonInput label="Main battery capacity (Ah):" name="batteryCapacity" value={form.batteryCapacity} onChange={handleInputChange} />
            <NeonInput label="Alternator nominal current (A):" name="alternatorCurrent" value={form.alternatorCurrent} onChange={handleInputChange} />
            <NeonInput label="Battery efficiency (Peukert):" name="peukert" value={form.peukert} onChange={handleInputChange} />

            <NeonSelect
                label="Amplifier Class:"
                name="ampClass"
                value={form.ampClass}
                onChange={handleInputChange}
                options={["A", "AB", "D", "T", "G", "H"]}
            />
             <NeonSelect
                label="Realistic Usage (type of use):"
                name="usage"
                value={form.usage}
                onChange={handleInputChange}
                options={[
                    { value: 10, label: "10% - burning tesla mode" },
                    { value: 20, label: "20% - " },
                    { value: 30, label: "30% - light use" },
                    { value: 40, label: "40% - common use" },
                    { value: 50, label: "50% - " },
                    { value: 60, label: "60% - intense use" },
                    { value: 70, label: "70% - " },
                    { value: 80, label: "80% - " },
                    { value: 90, label: "90% - SPL" },
                    { value: 100, label: "100% - continuous signal (test)" }
                ]}
            />
            <NeonRadioGroup
                label="Grounding connection method:"
                name="grounding"
                selectedValue={form.grounding}
                onChange={handleRadioChange}
                options={[
                    { value: 'battery', label: 'Negative direct to battery (2xL)' },
                    { value: 'chassis', label: 'Ground to chassis - good (1.3xL)' }
                ]}
            />
            <div className="pt-2 space-y-2">
               <NeonButton text=">>> GENERATE (CALCULATE) <<<" onClick={calculate} />
            </div>

          </div>
          {/* RIGHT PANE */}
          <div className="flex-grow flex flex-col">
            <label className="text-neon-green font-bold text-lg">OUTPUT</label>
            <textarea
              readOnly
              value={output}
              className="w-full h-full flex-grow bg-dark-input text-neon-green p-4 border border-dark-border mt-1 resize-none min-h-[400px] md:min-h-0 text-xs"
              rows={25}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
